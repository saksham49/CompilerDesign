//check for missing '{',';', '}'
/*
This
is
a 
multiline
comment
*/

#include<stdio.h>

void main()
{
	int s = 1+2+3+4;
	//float hellothisismorethanthirtyonecharacterssoitshouldgettruncated =2.3;
	double a=-3.134e-3;
	while(x>10) 
	{
		while(x>10) 
		{
			x = 0;
			cout << "ejnfoejnfo" << endl;
      		if(x>0) 
      		{
    			y=1;
    		}
    		else 
    		{
    			y=2;
    		}
		}
    	for(i=0;i<n;i++)
    	{
  			cout << "ejnfoejnfo" << endl;
  		}
		x = 0;
		z = 0;
	}
	cout << "kk";
	return;
}

